// Declare consts for Auth0 details required in this app
const CREATE_MOVIE = "create:movies";
const READ_MOVIE = "read:movies";
const UPDATE_MOVIE = "update:movies"
const DELETE_MOVIE = "delete:movies"
// The Auth0 id for this app
const AUTH0_CLIENT_ID = 'Ep3xZDxTZT9LawFXr89zXZlqFYcqGQwP';

// Your Auth0 domain aka account/ tenant
const AUTH0_DOMAIN = 'farouqca.eu.auth0.com';

// Users of this app require access to the API, identified by...
// This value is the 'Identifier' in your API settings 
const AUDIENCE = 'https://movieapi.com';

// Where Auth0 should return the token to after authentication
const AUTH0_CALLBACK_URL = 'http://localhost:3000';

// Initialise Auth0 connection with parameters defined above
const auth0WebAuth = new auth0.WebAuth({
  domain: AUTH0_DOMAIN,
  clientID: AUTH0_CLIENT_ID,
  redirectUri: AUTH0_CALLBACK_URL,
  responseType: 'id_token token',
  audience: AUDIENCE
});

const auth0Authentication = new auth0.Authentication(auth0WebAuth, {
  domain: AUTH0_DOMAIN,
  clientID: AUTH0_CLIENT_ID
});
