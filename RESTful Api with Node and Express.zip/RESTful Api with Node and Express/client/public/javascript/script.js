// API Base URL - the server address
const BASE_URL = `http://localhost:8080`;

function getHeaders() {
    // Return headers
    // Note that the access token is set in the Authorization: Bearer
    return new Headers({
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + getAccessToken()
    });
  }
  

// Requests will use the GET method and allow cross origin requests
const GET_INIT = { method: 'GET', credentials: 'include', headers: getHeaders(), mode: 'cors', cache: 'default' };

// Asynchronous Function getDataAsync from a url and return
async function getDataAsync(url) {
    // Try catch 
    try {
      // Call fetch and await the respose
      // Initally returns a promise
      const response = await fetch(url, GET_INIT);
  
      // As Resonse is dependant on fetch, await must also be used here
      const json = await response.json();
  
      // Output result to console (for testing purposes) 
      console.log(json);
  
      // Call function( passing he json result) to display data in HTML page
      //displayData(json);
      return json;
  
      // catch and log any errors
    } catch (err) {
      console.log(err);
      return err;
    }
}

   // Parse JSON
// Create movie rows
// Display in web page
function displayMovies(movies) {

  // Use the Array map method to iterate through the array of movies (in json format)
  // Each movies will be formated as HTML table rowsand added to the array
  // see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map
  // Finally the output array is inserted as the content into the <tbody id="movieRows"> element.


    
  const rows = movies.map(movie => {
    // returns a template string for each move, values are inserted using ${ }
    // <tr> is a table row and <td> a table division represents a column

    const showUpdate = checkAuth(UPDATE_MOVIE);
    const showDelete = checkAuth(DELETE_MOVIE);

     // Show addmovie button
      if (checkAuth(CREATE_MOVIE))
      $('#AddMovieButton').show();
      else
      $('#AddMovieButton').hide();

      // generate row

      let row = `<tr>
              <td>${movie.MovieId}</td>
              <td>${movie.MovieName}</td>
              <td>${movie.MovieDescription}</td>
              <td>${movie.MovieStock}</td>
              <td class="price">&euro;${Number(movie.MoviePrice).toFixed(2)}</td>`;
              //if user has permission to update - add the edit button
      if (showUpdate)
           row +=  `<td><button class="btn btn-xs" data-toggle="modal" data-target="#MovieFormDialog" 
              onclick="prepareMovieUpdate(${movie.MovieId})"><span class="oi oi-pencil"
               data-toggle="tooltip" title="Edit Movie"></span></button></td>`
               //if user has permission to delete- add delete button
      if (showDelete)
        row +=  `<td><button class="btn btn-xs" onclick="deleteMovie(${movie.MovieId})"><span class="oi oi-trash"
            data-toggle="tooltip" title="Delete Movie"></span></button></td>`

            //end row and return
              row += '</tr>';
          return row;       
          });

  // Set the innerHTML of the movieRows root element = rows
  // Why use join('') ???
  document.getElementById('movieRows').innerHTML = rows.join('');

} // end function


  // load and display genres in thhe left menu
function displayGenres(genres) {
    //console.log(genres);
  
    // use Array.map() to iterate through the list of genres
    // Returns an HTML link for each genre in the array
    const genLinks = genres.map(genre => {
      // The link has an onclick handler which will call updateMoviesView(id) pasing the genre id as a parameter
      return `<a href="#" class="list-group-item list-group-item-action" onclick="updateMoviesView(${genre.GenreId})">${genre.GenreName}</a>`;
    });
  
    // use  unshift to add a 'Show all' link at the start of the array of genLinks
    genLinks.unshift(`<a href="#" class="list-group-item list-group-item-action" onclick="loadMovies()">Show all</a>`);
  
    // Set the innerHTML of the movieRows element = the links contained in genlinks
    // .join('') converts an array to a string, replacing the , seperator with blank.
    document.getElementById('genreList').innerHTML = genLinks.join('');

      // Fill select list in movie form
      // first get the select input by its id
  
      let genSelect = document.getElementById("genreId");

      // Add default option (to the currently empty select)
      // options[genSelect.options.length] is the last option + 1
      // an option is made from a name, value pair
         while (genSelect.firstChild)
         genSelect.removeChild(genSelect.firstChild);
    
  


  // Add an option for each genre
  // iterate through genres adding each to the end of the options list
  // each option is made from genreName, genreId
  genSelect.add(new Option("Choose Genre", 0))
  for (i=0; i< genres.length; i++) {
    genSelect.options[genSelect.options.length] = new Option(genres[i].GenreName, genres[i].GenreId);
  }

} // end function

  // Load movies
// Get all genres and movies then display
async function loadMovies() {
  try {  
      //get list of genres
      const genres = await getDataAsync(`${BASE_URL}/genre`);
      //retrieve genres list calling displayGenres()
      if (genres != null)
      displayGenres(genres);
      //get list movies
      const movies = await getDataAsync(`${BASE_URL}/movie`);
      //retrieve movies list calling DisplayMovies()
      if (movies != null)
      displayMovies(movies);

  } // catch and log any errors
      catch (err) {
      console.log(err);
  }
}

// update movies list when genre is selected to show only movies from that genre
async function updateMoviesView(id) {
    try {
      // call the API enpoint which retrieves movies by genre (id)
      const movies = await getDataAsync(`${BASE_URL}/movie/bygen/${id}`);
      // Display the list of movies returned by the API
      displayMovies(movies);
  
    } // catch and log any errors
    catch (err) {
      console.log(err);
    }
  } 
  
  // Get form data and return as object for POST
// Uppercase first char to match DB
function getMovieForm() {

  // Get form fields
  const mId = document.getElementById('movieId').value;
  const genId = document.getElementById('genreId').value;
  const mName = document.getElementById('movieName').value;
  const mDesc = document.getElementById('movieDescription').value;
  const mStock = document.getElementById('movieStock').value;
  const mPrice = document.getElementById('moviePrice').value;

  // build movie object for Insert or Update
  // required for sending to the API
  const movieObj = {
    movieId: mId,
    genreId: genId,
    movieName: mName,
    movieDescription: mDesc,
    movieStock: mStock,
    moviePrice: mPrice
  }

  // return the body data
  return movieObj;
}
// Setup movie form (for inserting or updating)
function movieFormSetup(title) {
  // Set form title
  document.getElementById("movieFormTitle").innerHTML = title;

  // reset the form and change the title
  document.getElementById("MovieForm").reset();
  // form reset doesn't work for hidden inputs!!
  document.getElementById("movieId").value = 0;
}

// Add a new movie - called by form submit
// get the form data and send request to the API
async function addOrUpdateMovie() {
  // url for api call
  const url = `${BASE_URL}/movie`
  let httpMethod = "POST";

  // get new movie data as json (the request body)
  const movieObj = getMovieForm();

  // If movieId > 0 then this is an existing movie for update
  if (movieObj.movieId > 0) {
    httpMethod = "PUT";
  }
  // build the request object - note: POST
  // reqBodyJson added to the req body
  const request = {
      method: httpMethod,
      headers: getHeaders(),
      // credentials: 'include',
      mode: 'cors',
      // convert JS Object to JSON and add to request body
      body: JSON.stringify(movieObj)
    };

  // Try catch 
  try {
    // Call fetch and await the respose
    // fetch url using request object
    const response = await fetch(url, request);
    const json = await response.json();

    // Output result to console (for testing purposes) 
    console.log(json);

    // catch and log any errors
  } catch (err) {
    console.log(err);
    return err;
  }
  // Refresh movies list
  loadMovies();
}

  // When a movie is selected for update/ editing, get it by id and fill out the form
  async function prepareMovieUpdate(id) {
    try {
        // 1. Get movie by id
        const movie = await getDataAsync(`${BASE_URL}/movie/${id}`);

        // 2. Set up the form (title, etc.)
        movieFormSetup(`Update Movie ID: ${movie.MovieId}`);

        // 3. Fill out the form
        document.getElementById('movieId').value = movie.MovieId; // uses a hidden field - see the form
        document.getElementById('genreId').value = movie.MovieId;
        document.getElementById('movieName').value = movie.MovieName;
        document.getElementById('movieDescription').value = movie.MovieDescription;
        document.getElementById('movieStock').value = movie.MovieStock;
        document.getElementById('moviePrice').value = movie.MoviePrice;

    } // catch and log any errors
    catch (err) {
    console.log(err);
    }
  }


  // Delete movie by id using an HTTP DELETE request
  async function deleteMovie(id) {

    // Build the request object
    const request = {
      // set http method
      method: 'DELETE',
      headers: getHeaders(),
      // credentials: 'include',
      mode: 'cors',
    };
    // Cofirm delete
    if (confirm("Are you sure?")) {
        // build the api url for deleting a movie
        const url = `${BASE_URL}/movie/${id}`;
        // Try catch 
        try {
            // call the api and get a result
            const result = await fetch(url, request);
            const response = await result.json();
            // if success (true result), refresh movies list
            if (response == true)
              loadMovies();

        // catch and log any errors
        } catch (err) {
            console.log(err);
            return err;
        } 
    }
  }


// When this script is loaaded, call loadMovies() to add movies to the page
loadMovies();
