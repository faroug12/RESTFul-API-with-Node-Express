// Depencencies
const router = require('express').Router();

const genreService = require('../services/genreService.js');

// GET listing of all movies
// Address http://server:port/movie
// returns JSON
router.get('/', async (req, res) => {

    let result;
    // Get genres
    try {

      // Call the genre service to get all movies 
      result = await genreService.getGenres()
      res.json(result);

      // Catch and send errors  
      } catch (err) {
        res.status(500);
        res.send(err.message);
      }
});

// Export as a module
module.exports = router;
