
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_Objects#Using_a_constructor_function
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/default_parameters

function Movie(id = 0, gen = 0, name, desc, stock, price) {

    this.MovieId = id;
    this.GenreId = gen;
    this.MovieName = name;
    this.MovieDescription = desc;
    this.MovieStock = stock;
    this.MoviePrice = price;
}

module.exports = Movie;