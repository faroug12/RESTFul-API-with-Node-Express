// require the database connection
const movieRepository = require('../repositories/genreRepository.js');
// Get all genres via the repository
// return genres
let getGenres = async () => {

    let genres = await movieRepository.getGenres();
    return genres;
};

// Module exports
// expose these functions
module.exports = {
    getGenres
};