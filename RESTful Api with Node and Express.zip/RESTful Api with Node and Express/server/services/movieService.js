// require the database connection
const movieRepository = require('../repositories/movieRepository.js');
const movieValidator = require('../validators/movieValidators.js');

// Input validation package
// https://www.npmjs.com/package/validator

const validator = require('validator');

// Get all movies via the repository
// return movies
let getMovies = async () => {

    let movies = await movieRepository.getMovies();
    return movies;
};


// Get movie by id via the repository
// Validate input
// return movie
let getMovieById = async (movieId) => {

    let movie;

    // Validate input - important as a bad input could crash the server or lead to an attack
    // appending + '' to numbers as the validator only works with strings
    if (!movieValidator.validateId(movieId)) {
        console.log("getMovies service error: invalid id parameter");
        return "invalid parameter";
    }

    // get movie
    movie = await movieRepository.getMovieById(movieId);

    return movie;
};

// Get movies in a genre via the repository
// Validate input
// return movies
let getMovieByGenId = async (genId) => {

    let movies;

    //Validate input - important as a bad input could crash the server or lead to an attack
    // appending + '' to numbers as the validator only works with strings
    if (!movieValidator.validateId(genId)) {
        console.log("getMovies service error: invalid id parameter");
        return "invalid parameter";
    }

    movies = await movieRepository.getMovieByGenId(genId);

    return movies;
};

// Insert a new movie
// This function accepts movie data as a paramter from the controller.
let createMovie = async (movie) => {

    // declare variables
    let newlyInsertedMovie;

    // Call the movie validator - kept seperate to avoid clutter here
    let validatedMovie = movieValidator.validateNewMovie(movie);

    // If validation returned a movie object - save to database
    if (validatedMovie != null) {
        newlyInsertedMovie = await movieRepository.createMovie(validatedMovie);
    } else {

        // movie data failed validation 
        newlyInsertedMovie = {"error": "invalid movie"};

        // debug info
        console.log("movieService.createMovie(): form data validate failed");
    }

    // return the newly inserted movie
    return newlyInsertedMovie;
};

let updateMovie = async (movie) => {

    // Declare variables and consts
    let updatedMovie;

    // call the movie validator
    let validatedMovie = movieValidator.validateUpdateMovie(movie);

    // If validation returned a movie object - save to database
    if (validatedMovie != null) {
        updatedMovie = await movieRepository.updateMovie(validatedMovie);
    } else {

        // Movie data failed validation 
        updatedMovie = {"error": "Movie update failed"};

        // debug info
        console.log("movieService.updateMovie(): form data validate failed");
    }

    // return the newly inserted movie
    return updatedMovie;

};


let deleteMovie = async (movieId) => {

    let deleteResult = false;

    // Validate input - important as a bad input could crash the server or lead to an attack
    // appending + '' to numbers as the validator only works with strings
    if (movieValidator.validateId(movieId) === false) {
        console.log("deleteMovies service error: invalid id parameter");
        return false;
    }

    // delete movir by id
    // result: true or false
    deleteResult = await movieRepository.deleteMovie(movieId);

    return deleteResult;
};

// Module exports
// expose these functions
module.exports = {
    getMovies,
    getMovieById,
    getMovieByGenId,
    createMovie,
    updateMovie,
    deleteMovie
};